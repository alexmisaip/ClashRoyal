package com.example.etna.myapp;

import android.app.LauncherActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

public class ArenaActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    List<Map<String, String>> data = new ArrayList<Map<String, String>>();
    public final String API_URL = "http://www.clashapi.xyz";

    ArrayList<String> id_arrays = new ArrayList<String>();

    public static final String KEY_NAME = "key_id";
    public static final String KEY_TYPE = "key_type";
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent i = new Intent(ArenaActivity.this, DetailActivity.class);

        String[] stockArr = new String[id_arrays.size()];
        stockArr = id_arrays.toArray(stockArr);
        String s = stockArr[position];

        i.putExtra(KEY_NAME,s);
        i.putExtra(KEY_TYPE, "arenas");

        startActivity(i);
    }

    public class Arenas {
        public String idName, _id;
        public int minTrophies;

        public Arenas(String idName, String id, int minTrophies) {
            this._id = id;
            this.idName = idName;
            this.minTrophies = minTrophies;
        }
    }

    public interface  Apicr {
        @GET("api/arenas")
        Call<List<Arenas>> arenas();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arena);
        final ListView listView = (ListView) findViewById(R.id.list_item);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Apicr test = retrofit.create(Apicr.class);
        Call<List<Arenas>> call = test.arenas();

        call.enqueue(new Callback<List<Arenas>>() {
            @Override
            public void onResponse(Call<List<Arenas>> call, Response<List<Arenas>> response) {
                List<Arenas> arenas = response.body();
                for (Arenas arena : arenas) {
                    Map<String, String> listItems = new HashMap<String, String>(2);

                    id_arrays.add(arena._id);
                    listItems.put("title", arena.idName);
                    listItems.put("trophies", ""+arena.minTrophies);
                    data.add(listItems);
                }
                SimpleAdapter adapter = new SimpleAdapter(ArenaActivity.this, data, android.R.layout.simple_list_item_2,
                        new String[] {"title", "trophies"},
                        new int[] {android.R.id.text1, android.R.id.text2});
                listView.setAdapter(adapter);
            }
            @Override
            public void onFailure (Call < List < Arenas >> call, Throwable throwable){

            }
        });

        listView.setOnItemClickListener(this);
    }

}
