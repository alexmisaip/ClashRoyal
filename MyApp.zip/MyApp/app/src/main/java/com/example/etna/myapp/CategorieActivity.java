package com.example.etna.myapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class CategorieActivity extends AppCompatActivity {

    public Button btnCard;
    public Button btnArena;
    public Button btnLeague;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorie);
        ButtonCardListener();
        ButtonMapListener();
        ButtonLeagueListener();
    }

    public void ButtonCardListener() {
        btnCard = (Button)findViewById(R.id.btncard);
        btnCard.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(CategorieActivity.this,CardActivity.class);
                        startActivity(intent);
                    }
                }
        );
    }

    public void ButtonMapListener() {
        btnArena = (Button)findViewById(R.id.btnarena);
        btnArena.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(CategorieActivity.this,ArenaActivity.class);
                        startActivity(intent);
                    }
                }
        );
    }

    public void ButtonLeagueListener() {
        btnLeague = (Button)findViewById(R.id.btnleague);
        btnLeague.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(CategorieActivity.this,LeagueActivity.class);
                        startActivity(intent);
                    }
                }
        );
    }
}

