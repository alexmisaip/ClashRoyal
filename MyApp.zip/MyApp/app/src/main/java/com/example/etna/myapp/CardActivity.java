package com.example.etna.myapp;

import android.app.LauncherActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

public class CardActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    List<Map<String, String>> data = new ArrayList<Map<String, String>>();
    public final String API_URL = "http://www.clashapi.xyz";

    ArrayList<String> id_arrays = new ArrayList<String>();

    public static final String KEY_NAME = "key_id";
    public static final String KEY_TYPE = "key_type";
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent i = new Intent(CardActivity.this, DetailActivity.class);

        String[] stockArr = new String[id_arrays.size()];
        stockArr = id_arrays.toArray(stockArr);
        String s = stockArr[position];

        i.putExtra(KEY_NAME,s);
        i.putExtra(KEY_TYPE, "cards");

        startActivity(i);
    }

    public class Cards {
        public String name, type, _id;

        public Cards(String name, String id, String type) {
            this._id = id;
            this.name = name;
            this.type = type;
        }
    }

    public interface  Apicr {
        @GET("api/cards")
        Call<List<Cards>> cards();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);
        final ListView listView = (ListView) findViewById(R.id.list_item);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Apicr test = retrofit.create(Apicr.class);
        Call<List<Cards>> call = test.cards();

        call.enqueue(new Callback<List<Cards>>() {
            @Override
            public void onResponse(Call<List<Cards>> call, Response<List<Cards>> response) {
                List<Cards> cards = response.body();
                for (Cards card : cards) {
                    Map<String, String> listItems = new HashMap<String, String>(2);

                    id_arrays.add(card._id);
                    listItems.put("title", card.name);
                    listItems.put("Type", card.type);
                    data.add(listItems);
                }
                SimpleAdapter adapter = new SimpleAdapter(CardActivity.this, data, android.R.layout.simple_list_item_2,
                        new String[] {"title", "Type"},
                        new int[] {android.R.id.text1, android.R.id.text2});
                listView.setAdapter(adapter);
            }
            @Override
            public void onFailure (Call < List < Cards >> call, Throwable throwable){

            }
        });

        listView.setOnItemClickListener(this);
    }

}
