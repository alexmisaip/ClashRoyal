package com.example.etna.myapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

public class DetailActivity extends AppCompatActivity {

    public final String API_URL = "http://www.clashapi.xyz";
    public String name;

    public class Detail {
        public String name, rarity, type, description;
        public int victoryGold, minTrophies;

        public Detail(String name, String rarity, String type, String description, int victoryGold, int minTrophies) {
            this.name = name;
            this.victoryGold = victoryGold;
            this.minTrophies = minTrophies;
            this.rarity = rarity;
            this.type = type;
            this.description = description;
        }
    }

    public interface  Apicr {
        @GET("api/{type}/{id}")
        Call<Detail> details(
                @Path("type") String type,
                @Path("id") String id
        );
    }

    private TextView textViewName;
    private TextView textViewVicGold;
    private TextView textViewMinTroph;
    private TextView textViewRarity;
    private TextView textViewTypeC;
    private TextView textViewDesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        textViewName = (TextView) findViewById(R.id.textViewName);
        textViewVicGold = (TextView) findViewById(R.id.textViewVicGold);
        textViewMinTroph = (TextView) findViewById(R.id.textViewMinTroph);
        textViewRarity = (TextView) findViewById(R.id.textViewRarity);
        textViewTypeC = (TextView) findViewById(R.id.textViewTypeC);
        textViewDesc = (TextView) findViewById(R.id.textViewDesc);
        OnClickButtonShare();
        final String type = getIntent().getStringExtra("key_type");
        String id = getIntent().getStringExtra("key_id");

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Apicr test = retrofit.create(Apicr.class);
        Call<Detail> call = test.details(type, id);

        call.enqueue(new Callback<Detail>() {
            @Override
            public void onResponse(Call<Detail> call, Response<Detail> response) {
                Detail details = response.body();
                if (type.equals("leagues") || type.equals("arenas")) {
                    textViewName.setText(details.name);
                    textViewVicGold.setText(String.valueOf(details.victoryGold));
                    textViewMinTroph.setText(String.valueOf(details.minTrophies));
                    name = String.valueOf(details.name);
                }
                if (type.equals("cards")){
                    textViewName.setText(details.name);
                    textViewRarity.setText(String.valueOf(details.rarity));
                    textViewTypeC.setText(String.valueOf(details.type));
                    textViewDesc.setText(String.valueOf(details.description));
                    name = String.valueOf(details.name);
                }
            }
            @Override
            public void onFailure (Call <Detail> call, Throwable throwable){
            }
        });
    }
    public void OnClickButtonShare() {
        Button btnshare = (Button)findViewById(R.id.btnshare);
        btnshare.setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Intent sendIntent = new Intent();
                        sendIntent.setAction(Intent.ACTION_SEND);
                        sendIntent.putExtra(Intent.EXTRA_TEXT, name);
                        sendIntent.setType("text/plain");
                        startActivity(sendIntent);
                    }
                }
        );
    }
}
